---
name: openclaw-agent-creator
description: Create a new OpenClaw agent with its own Telegram bot, isolated workspace, and Visa CLI plugin. Use when the user asks to "create an agent", "spin up a new openclaw agent", "make a new telegram bot agent", "create another agent like Reggie", or discusses creating isolated AI agents with payment capabilities.
version: 1.0.0
---

# OpenClaw Agent Creator + Visa CLI Plugin

Creates a fully isolated OpenClaw agent with its own Telegram bot, model of choice, Visa CLI payment tools, and fresh context. No shared memory, sessions, or cron jobs with other agents.

## Prerequisites

- OpenClaw installed (`npx openclaw --version`)
- An Anthropic or OpenAI API key
- The `@visa/oc-visa-cli-plugin` built and installed at `~/.openclaw/extensions/oc-visa-cli-plugin/`

## Step-by-Step Process

### 1. Gather Info from User

Ask for:
- **Agent name** (e.g., "Reggie", "Scout", "Atlas")
- **Agent purpose** (general purpose, research, creative, etc.)
- **Model preference** (openai/gpt-5.5, anthropic/claude-opus-4-7, etc.)
- **Telegram bot username** (they need to create one via @BotFather first)

### 2. Create Telegram Bot

Walk the user through BotFather:
1. Open Telegram, search for `@BotFather`
2. Send `/newbot`
3. Enter display name (the agent name)
4. Enter username (must end in `bot`, e.g., `scout_cuy_bot`)
5. Copy the bot token (format: `1234567890:AAH-xxxxx`)

### 3. Get API Keys

**Model API key:**
- OpenAI: https://platform.openai.com/api-keys
- Anthropic: https://console.anthropic.com/settings/keys

**Visa CLI API key:**
```bash
npx @visa/cli api-keys create <agent-name>
```
Returns a `vk_...` key.

### 4. Create Agent Directory Structure

Replace `{AGENT_ID}` with lowercase agent name (e.g., "reggie", "scout"):

```bash
mkdir -p ~/.openclaw/workspaces/{AGENT_ID}/memory
mkdir -p ~/.openclaw/agents/{AGENT_ID}/sessions
mkdir -p ~/.openclaw/agents/{AGENT_ID}/agent
```

### 5. Create Workspace Files

**SOUL.md** at `~/.openclaw/workspaces/{AGENT_ID}/SOUL.md`:
```markdown
# SOUL.md - Who {AGENT_NAME} Is

## Core
**{AGENT_NAME}** - {brief description of purpose}

## Style
- Concise and direct
- No filler, no sycophancy
- Never use em dashes. Use periods, commas, colons, semicolons, or parentheses instead.

## Tools
{AGENT_NAME} has access to Visa CLI tools (image gen, music gen, crypto prices, payments). Use them proactively when relevant.

## Boundaries
- Private info stays private
- Ask before sending anything external
```

**USER.md** at `~/.openclaw/workspaces/{AGENT_ID}/USER.md` -- minimal user context.

**MEMORY.md** at `~/.openclaw/workspaces/{AGENT_ID}/MEMORY.md`:
```markdown
# Memory Index

_(Empty, starts fresh)_
```

### 6. Create Auth Profiles (CRITICAL FORMAT)

OpenClaw's `auth-profiles.json` requires the **v1 format with `profiles` wrapper**:

```json
{
  "version": 1,
  "profiles": {
    "{PROVIDER}:default": {
      "type": "api_key",
      "provider": "{PROVIDER}",
      "key": "{API_KEY}"
    }
  }
}
```

Where `{PROVIDER}` is `openai` or `anthropic`.

Write to: `~/.openclaw/agents/{AGENT_ID}/agent/auth-profiles.json`
Then: `chmod 600` the file.

**Common mistakes that silently fail:**
- Writing `{"openai": {"apiKey": "..."}}` (legacy flat format) to `auth-profiles.json`. This file expects the v1 format with `profiles` wrapper.
- Missing `"type": "api_key"` causes the credential parser to reject the entry.
- Missing `"provider"` field causes the provider matcher to skip it.
- The legacy flat format only works in a file named `auth.json` (different filename).

### 7. Configure openclaw.json

```json
{
  "agents": {
    "list": [
      {
        "id": "{AGENT_ID}",
        "default": true,
        "name": "{AGENT_NAME}",
        "workspace": "~/.openclaw/workspaces/{AGENT_ID}",
        "model": {
          "primary": "openai/gpt-5.5"
        }
      }
    ]
  },
  "channels": {
    "telegram": {
      "enabled": true,
      "botToken": "{BOT_TOKEN}",
      "dmPolicy": "allowlist",
      "allowFrom": ["{USER_TELEGRAM_ID}"],
      "groupPolicy": "allowlist",
      "streaming": { "mode": "partial" }
    },
    "discord": { "enabled": false }
  },
  "plugins": {
    "entries": {
      "telegram": { "enabled": true },
      "oc-visa-cli-plugin": {
        "enabled": true,
        "config": {
          "apiKey": "{VISA_API_KEY}"
        }
      }
    }
  }
}
```

### 8. Configure LaunchAgent Environment

The LaunchAgent plist at `~/Library/LaunchAgents/ai.openclaw.gateway.plist` needs these env vars:

| Key | Value |
|---|---|
| `TELEGRAM_BOT_TOKEN` | The bot token from BotFather |
| `OPENAI_API_KEY` | OpenAI key (if using OpenAI models) |
| `VISA_CLI_API_KEY` | The `vk_...` key |

The Visa CLI plugin reads `VISA_CLI_API_KEY` (or `VISA_API_KEY`) from the environment as a fallback when the config object doesn't pass through.

To edit the plist, add `<key>` / `<string>` pairs inside the `<dict>` under `EnvironmentVariables`.

### 9. Clear Stale State

```bash
rm -rf ~/.openclaw/agents/{AGENT_ID}/sessions/*
rm -f ~/.openclaw/openclaw.json.bak*
rm -f ~/.openclaw/logs/config-health.json
```

Write `{"version":1,"jobs":[]}` to `~/.openclaw/cron/jobs.json` to clear any inherited cron jobs.

**Docker/native switch warning:** If sessions were created in Docker, they contain `/home/node/...` paths that crash the native runtime. Always nuke sessions when switching.

### 10. Copy Skills for Sandbox Access

Sandboxed agents cannot read files under `~/.openclaw/extensions/`. The Visa CLI plugin ships skill files (`SKILL.md`) that the agent needs to understand when and how to call each tool. Without this step, tools register but the agent silently ignores them.

Copy the skills into the agent's accessible skills directory (symlinks will not work -- OpenClaw rejects them as "symlink-escape"):

```bash
cp -r ~/.openclaw/extensions/oc-visa-cli-plugin/skills/visa-cli ~/.openclaw/skills/visa-cli
cp -r ~/.openclaw/extensions/oc-visa-cli-plugin/skills/openclaw-agent-creator ~/.openclaw/skills/openclaw-agent-creator
```

Enable them in `openclaw.json`:

```json
{
  "skills": {
    "entries": {
      "visa-cli": { "enabled": true },
      "openclaw-agent-creator": { "enabled": true }
    }
  }
}
```

### 11. Install and Start

```bash
npx openclaw gateway install
npx openclaw gateway restart
```

Verify: `npx openclaw status`

### 12. Test

- Send a message on Telegram
- Ask the agent to generate an image (tests Visa CLI)
- Ask for a crypto price (tests Visa CLI)

## Multi-Agent on Same Machine

Each agent needs its own Telegram bot, workspace, sessions, and auth. OpenClaw runs one gateway per machine. For multiple agents, use `agents.list` with `bindings` for Telegram account routing. For full isolation, use separate machines.

## Troubleshooting

| Error | Fix |
|---|---|
| "Missing API key for provider" | Use v1 auth-profiles.json format with `profiles` wrapper |
| "ENOENT: mkdir '/home/node'" | Delete sessions: `rm -rf ~/.openclaw/agents/{ID}/sessions/*` |
| "Config auto-restored from backup" | Delete `~/.openclaw/openclaw.json.bak*` |
| "Unknown model: openai/gpt-5.5" | Update OpenClaw: `npm install -g openclaw@latest` |
| Telegram not responding | Restart gateway; don't call getUpdates API manually |
| "Visa CLI API key not configured" | Set `VISA_CLI_API_KEY` env var or config.apiKey |
| Plugin "failed to load" | Rebuild plugin against matching OpenClaw version |
| Tools register but agent never calls them | Copy skills out of extensions dir: `cp -r ~/.openclaw/extensions/oc-visa-cli-plugin/skills/* ~/.openclaw/skills/` (see step 10) |
| "symlink-escape" error | Used `ln -s` instead of `cp -r` for skills. Remove symlinks and copy. |
