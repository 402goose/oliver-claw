---
name: visa-cli
description: Generate images, video, music, audio, 3D models, transcribe audio, run LLMs, and query crypto prices via Visa CLI
---

# Visa CLI

You have access to Visa CLI tools for AI generation and crypto data. Use them naturally when the user asks for any creative media or blockchain information.

## Setup (if the user doesn't have a key yet)

If a tool call returns a setup error, walk the user through this one-time process:

```
1. Install visa-cli (if not installed):
   npm install -g @visa/cli

2. Create an API key:
   visa api-keys create --label openclaw

3. Configure the key (pick one):
   a. Config: plugins.entries.oc-visa-cli-plugin.config.apiKey = "vk_..."
   b. Env var: export VISA_CLI_API_KEY="vk_..."

4. Ensure the tool sandbox allows plugin tools:
   Under tools.sandbox.tools.alsoAllow, add "group:plugins"

5. Ensure the visa-cli skill is enabled:
   Under skills.entries, add "visa-cli": { "enabled": true }

6. Verify agent sandbox mode:
   Agents using sandbox.mode="all" will block plugin skill reads.
   Use "non-main" instead for agents that need Visa CLI tools.

7. Restart the gateway:
   openclaw gateway restart
```

> **Note:** The postinstall script (`scripts/postinstall.mjs`) handles steps 4-5
> automatically on `npm install`. Step 6 requires manual review — the script
> warns but does not change agent sandbox modes.

## When to use which tool

| User says... | Call |
|---|---|
| "generate an image / picture / photo of..." | `visa_generate_image` |
| "make me a video of..." | `visa_generate_video` |
| "generate a song / track / music..." | `visa_generate_music` |
| "say this out loud / text to speech / read this" | `visa_generate_audio` (tier: tts) |
| "make a sound effect / ambient sound" | `visa_generate_audio` (tier: sfx) |
| "create a 3D model of..." | `visa_generate_3d` |
| "upscale this image" | `visa_upscale_image` |
| "transcribe this audio / video" | `visa_transcribe_audio` |
| "ask [model] / run this prompt through an LLM" | `visa_run_llm` |
| "what's my balance / account status" | `visa_get_status` |
| "show my transactions / what did I spend" | `visa_transaction_history` |
| "what tools are available" | `visa_discover_tools` |
| "price of [token] on [chain]" | `visa_query_token_price` |

## Pricing reference

Always quote the price before calling a paid tool.

| Tool | Cheapest | Default | Best |
|---|---|---|---|
| Image | fast $0.01 | balanced $0.04 | pro $0.06 |
| Video | fast $0.10 | balanced $0.15 | pro $0.20 |
| Music | suno $0.10 | — | — |
| Audio TTS | tts $0.03 | — | — |
| Audio SFX | sfx $0.04 | — | — |
| 3D model | trellis $0.08 | — | — |
| Upscale | aura $0.03 | — | — |
| Transcribe | whisper $0.02 | — | — |
| LLM | fast $0.01 | — | reasoning $0.09 |
| Token price | ~$0.02 | — | — |

## Tier guidance

- **Image tier `balanced`** — good quality, good speed. Default for most requests.
- **Image tier `fast`** — drafts, iteration, cheapest option.
- **Image tier `pro`** — hero images, high detail, print quality.
- **Image tier `text_heavy`** — when the image contains rendered text or logos.
- **Image tier `vector`** — flat illustrations, icons, vector art.
- **LLM tier `fast`** — most questions, cheapest.
- **LLM tier `coding`** — code generation and debugging.
- **LLM tier `search`** — questions about current events (web-grounded).
- **LLM tier `reasoning`** — complex analysis. Warn user it's ~$0.09/call.

## Delivering results

- After generating an image or video, send the returned URL via `message` to deliver it to the user.
- After generating music or audio, send the returned URL — the user can open it in their browser.

## Example flows

**Image → Telegram:**
1. User: "generate me a neon cityscape"
2. Call `visa_generate_image({ prompt: "neon cityscape at dusk", tier: "balanced" })`
3. Response includes `urls[0]` — send it via `message` to deliver over Telegram.

**Music:**
1. User: "make me a lo-fi study track"
2. Call `visa_generate_music({ prompt: "lo-fi hip hop, mellow, piano, vinyl crackle", instrumental: true })`
3. Response includes audio URL — send it.

**Token price:**
1. User: "what's the price of USDC on base?"
2. Call `visa_query_token_price({ chain: "base", token_address: "0x..." })`
3. Return the price data.
