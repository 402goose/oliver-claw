#!/usr/bin/env node
// @purpose Removes skill files that were copied by postinstall.mjs.
//          Reads the same config to find where skills were placed, then deletes
//          only the skill directories that belong to this plugin.

import {
  readFileSync,
  readdirSync,
  rmSync,
  existsSync,
} from "node:fs";
import { join, resolve } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";
import { dirname } from "node:path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const OPENCLAW_DIR = join(homedir(), ".openclaw");
const CONFIG_PATH = join(OPENCLAW_DIR, "openclaw.json");
const FALLBACK_SKILLS_DIR = join(OPENCLAW_DIR, "skills");

// The skills directory in the plugin package (source of truth for skill names)
const PLUGIN_SKILLS_DIR = resolve(__dirname, "..", "skills");

function log(msg) {
  console.log(`[oc-visa-cli-plugin preuninstall] ${msg}`);
}

function warn(msg) {
  console.warn(`[oc-visa-cli-plugin preuninstall] WARN: ${msg}`);
}

/**
 * Collect all candidate directories where skills may have been installed.
 * Includes every extraDirs entry + the fallback.
 */
export function collectTargetDirs(
  configPath = CONFIG_PATH,
  fallback = FALLBACK_SKILLS_DIR,
) {
  const dirs = new Set();

  try {
    const raw = readFileSync(configPath, "utf-8");
    const config = JSON.parse(raw);
    const extraDirs = config?.skills?.load?.extraDirs;

    if (Array.isArray(extraDirs)) {
      for (const dir of extraDirs) {
        const resolved = dir.startsWith("~")
          ? join(homedir(), dir.slice(1))
          : resolve(dir);
        dirs.add(resolved);
      }
    }
  } catch {
    // Config doesn't exist or isn't valid JSON
  }

  dirs.add(fallback);
  return [...dirs];
}

/**
 * Get the list of skill directory names bundled with this plugin.
 */
export function getPluginSkillNames(sourceDir = PLUGIN_SKILLS_DIR) {
  if (!existsSync(sourceDir)) return [];
  return readdirSync(sourceDir, { withFileTypes: true })
    .filter((e) => e.isDirectory())
    .map((e) => e.name);
}

/**
 * Remove copied skill directories from all candidate target dirs.
 * Returns an array of removed paths.
 */
export function removeSkills(
  sourceDir = PLUGIN_SKILLS_DIR,
  configPath = CONFIG_PATH,
  fallback = FALLBACK_SKILLS_DIR,
) {
  const skillNames = getPluginSkillNames(sourceDir);
  if (skillNames.length === 0) {
    log("No skill names found in plugin source -- nothing to remove.");
    return [];
  }

  const targetDirs = collectTargetDirs(configPath, fallback);
  const removed = [];

  for (const targetDir of targetDirs) {
    for (const name of skillNames) {
      const skillPath = join(targetDir, name);
      if (existsSync(skillPath)) {
        rmSync(skillPath, { recursive: true, force: true });
        removed.push(skillPath);
        log(`Removed "${name}" from ${targetDir}`);
      }
    }
  }

  return removed;
}

// ── Main ──

const isDirectRun =
  process.argv[1] && resolve(process.argv[1]) === resolve(__filename);

if (isDirectRun) {
  try {
    const removed = removeSkills();
    if (removed.length > 0) {
      log(`Done -- removed ${removed.length} skill dir(s).`);
    } else {
      log("No copied skills found to remove.");
    }
  } catch (err) {
    warn(`Failed to remove skills: ${err.message}`);
    // Non-fatal — don't break npm uninstall
    process.exit(0);
  }
}
