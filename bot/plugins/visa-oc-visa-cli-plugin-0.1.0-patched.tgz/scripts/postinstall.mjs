#!/usr/bin/env node
// @purpose Installs bundled skills into a sandbox-readable location and
//          configures ~/.openclaw/openclaw.json for Visa CLI plugin usage.

import { readFile, writeFile, copyFile, mkdir } from "node:fs/promises";
import {
  readFileSync,
  readdirSync,
  mkdirSync,
  cpSync,
  existsSync,
} from "node:fs";
import { join, resolve, dirname } from "node:path";
import { homedir } from "node:os";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const PREFIX = "[oc-visa-cli-plugin postinstall]";
const OPENCLAW_DIR = join(homedir(), ".openclaw");
const CONFIG_PATH = join(OPENCLAW_DIR, "openclaw.json");
const FALLBACK_SKILLS_DIR = join(OPENCLAW_DIR, "skills");
const PLUGIN_SKILLS_DIR = resolve(__dirname, "..", "skills");

function log(msg) {
  console.log(`${PREFIX} ${msg}`);
}

function warn(msg) {
  console.warn(`${PREFIX} WARN: ${msg}`);
}

export function getConfigPath() {
  return CONFIG_PATH;
}

export async function readConfig(configPath) {
  if (!existsSync(configPath)) {
    return {};
  }
  const raw = await readFile(configPath, "utf-8");
  try {
    return JSON.parse(raw);
  } catch (err) {
    warn(`Invalid JSON in ${configPath}; treating config as empty: ${err.message}`);
    return {};
  }
}

export async function writeConfig(configPath, config) {
  const dir = dirname(configPath);
  if (!existsSync(dir)) {
    await mkdir(dir, { recursive: true });
  }
  if (existsSync(configPath)) {
    await copyFile(configPath, `${configPath}.bak.${Date.now()}.${process.pid}`);
  }
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, "utf-8");
}

export function ensureGroupPlugins(config) {
  if (!config.tools) config.tools = {};
  if (!config.tools.sandbox) config.tools.sandbox = {};
  if (!config.tools.sandbox.tools) config.tools.sandbox.tools = {};

  const sandboxTools = config.tools.sandbox.tools;
  if (!Array.isArray(sandboxTools.alsoAllow)) {
    sandboxTools.alsoAllow = [];
  }

  if (sandboxTools.alsoAllow.includes("group:plugins")) {
    return false;
  }

  sandboxTools.alsoAllow.push("group:plugins");
  log('Added "group:plugins" to tools.sandbox.tools.alsoAllow');
  return true;
}

export function ensureSkillEntry(config) {
  if (!config.skills) config.skills = {};
  if (!config.skills.entries) config.skills.entries = {};

  if (config.skills.entries["visa-cli"] !== undefined) {
    return false;
  }

  config.skills.entries["visa-cli"] = { enabled: true };
  log('Enabled "visa-cli" in skills.entries');
  return true;
}

export function warnSandboxModeAll(config) {
  const warned = [];

  if (!config.agents || !Array.isArray(config.agents.list)) {
    return warned;
  }

  for (const agent of config.agents.list) {
    const id = agent.id || agent.name || "(unknown)";
    if (agent.sandbox?.mode === "all") {
      warn(
        `Agent "${id}" uses sandbox.mode="all", which blocks plugin skill reads. Use "non-main" for agents that need Visa CLI tools.`,
      );
      warned.push(id);
    }
  }

  return warned;
}

function canCreate(dirPath) {
  try {
    mkdirSync(dirPath, { recursive: true });
    return true;
  } catch {
    return false;
  }
}

export function resolveTargetDir(
  configPath = CONFIG_PATH,
  fallback = FALLBACK_SKILLS_DIR,
) {
  try {
    const raw = readFileSync(configPath, "utf-8");
    const config = JSON.parse(raw);
    const extraDirs = config?.skills?.load?.extraDirs;

    if (Array.isArray(extraDirs) && extraDirs.length > 0) {
      for (const dir of extraDirs) {
        if (typeof dir !== "string" || dir.length === 0) continue;
        const resolved = dir.startsWith("~")
          ? join(homedir(), dir.slice(1))
          : resolve(dir);
        if (existsSync(resolved) || canCreate(resolved)) {
          return resolved;
        }
      }
    }
  } catch {
    // Config doesn't exist or isn't valid JSON; use fallback.
  }

  return fallback;
}

export function copySkills(
  sourceDir = PLUGIN_SKILLS_DIR,
  targetDir = undefined,
  configPath = CONFIG_PATH,
  fallback = FALLBACK_SKILLS_DIR,
) {
  if (!existsSync(sourceDir)) {
    warn(`No skills directory found at ${sourceDir} -- skipping`);
    return [];
  }

  const dest = targetDir ?? resolveTargetDir(configPath, fallback);
  mkdirSync(dest, { recursive: true });

  const copied = [];
  for (const entry of readdirSync(sourceDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;

    const src = join(sourceDir, entry.name);
    const dst = join(dest, entry.name);
    cpSync(src, dst, { recursive: true, force: true });
    copied.push(entry.name);
    log(`Copied skill "${entry.name}" -> ${dst}`);
  }

  return copied;
}

export async function configureOpenclaw(configPath = getConfigPath()) {
  const config = await readConfig(configPath);
  const groupModified = ensureGroupPlugins(config);
  const skillModified = ensureSkillEntry(config);
  const modified = groupModified || skillModified;

  warnSandboxModeAll(config);

  if (modified) {
    await writeConfig(configPath, config);
    log(`Updated ${configPath}`);
  } else {
    log("Config already up to date");
  }

  return config;
}

export async function runPostinstall({
  configPath = getConfigPath(),
  sourceDir = PLUGIN_SKILLS_DIR,
  targetDir = undefined,
  fallback = FALLBACK_SKILLS_DIR,
} = {}) {
  const config = await configureOpenclaw(configPath);
  const skills = copySkills(sourceDir, targetDir, configPath, fallback);
  log(
    skills.length > 0
      ? `Done -- ${skills.length} skill(s) installed.`
      : "No skills to install.",
  );
  return { config, skills };
}

const isDirectRun =
  process.argv[1] && resolve(process.argv[1]) === resolve(__filename);

if (isDirectRun) {
  runPostinstall().catch((err) => {
    warn(`Postinstall skipped: ${err.message}`);
    process.exit(0);
  });
}
