# @visa/oc-visa-cli-plugin

OpenClaw plugin for Visa CLI. Registers AI media generation, crypto price queries, account status, transaction history, and payment tools into the OpenClaw gateway.

## Install

```bash
npm install @visa/oc-visa-cli-plugin
```

The postinstall script configures `~/.openclaw/openclaw.json` and copies bundled skills into an OpenClaw-readable skills directory. If you install from the monorepo, build first:

```bash
pnpm --filter @visa/oc-visa-cli-plugin build
```

## Configuration

Add the plugin to `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "entries": {
      "oc-visa-cli-plugin": {
        "enabled": true,
        "config": {
          "apiKey": "vk_..."
        }
      }
    }
  }
}
```

If `apiKey` is omitted, the plugin falls back to `VISA_CLI_API_KEY`, then `VISA_API_KEY`.

Create an API key if needed:

```bash
visa api-keys create --label openclaw
```

Restart the gateway after config changes:

```bash
openclaw gateway restart
```

## Postinstall

The postinstall script is idempotent and safe to run multiple times. It:

| Issue | Action |
|---|---|
| #798 | Copies bundled `visa-cli` and `openclaw-agent-creator` skills into the first usable `skills.load.extraDirs` entry, or `~/.openclaw/skills/` |
| #807 | Adds `group:plugins` to `tools.sandbox.tools.alsoAllow` |
| #803 | Enables `skills.entries["visa-cli"]` if no entry exists |
| #808 | Warns when an agent uses `sandbox.mode: "all"` because that blocks plugin skill reads |

A `.bak` backup is created before any `openclaw.json` write. Skill copies are physical copies, not symlinks, because OpenClaw rejects symlinks that escape the sandbox.

## Manual Sandbox Setup

If postinstall did not run, copy skills manually:

```bash
cp -r ~/.openclaw/extensions/oc-visa-cli-plugin/skills/visa-cli ~/.openclaw/skills/visa-cli
cp -r ~/.openclaw/extensions/oc-visa-cli-plugin/skills/openclaw-agent-creator ~/.openclaw/skills/openclaw-agent-creator
```

Then ensure these entries exist:

```json
{
  "tools": {
    "sandbox": {
      "tools": {
        "alsoAllow": ["group:plugins"]
      }
    }
  },
  "skills": {
    "entries": {
      "visa-cli": {
        "enabled": true
      }
    }
  }
}
```

Agents using `sandbox.mode: "all"` should be changed to `non-main` if they need Visa CLI tools.

## Tools Registered

| Tool | Description |
|---|---|
| `visa_generate_image` | Generate images |
| `visa_generate_video` | Generate video clips |
| `visa_generate_music` | Generate music tracks |
| `visa_generate_audio` | Text-to-speech and sound effects |
| `visa_generate_3d` | Generate 3D models |
| `visa_upscale_image` | Upscale an existing image |
| `visa_transcribe_audio` | Transcribe audio/video to text |
| `visa_run_llm` | Run a prompt through an external LLM |
| `visa_get_status` | Check account balance and status |
| `visa_transaction_history` | View recent transactions |
| `visa_discover_tools` | List available Visa CLI tools |
| `visa_execute_tool` | Execute an arbitrary Visa CLI tool by name |
| `visa_query_token_price` | Query on-chain token prices |

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Tools register but agent never calls them | Sandbox blocks `SKILL.md` reads from extensions dir | Copy skills into `~/.openclaw/skills/` or rerun postinstall |
| "Visa CLI API key not configured" | Missing API key in config and env | Set `apiKey`, `VISA_CLI_API_KEY`, or `VISA_API_KEY` |
| "symlink-escape" error | Skills were symlinked | Remove symlinks and copy skill folders physically |
| Agent says it lacks image generation capabilities | Skill file is not loaded | Verify `~/.openclaw/skills/visa-cli/SKILL.md` exists and `skills.entries.visa-cli.enabled` is true |

## Development

```bash
npm run build
npm test
npm run test:coverage
```

## License

See LICENSE in the repository root.
